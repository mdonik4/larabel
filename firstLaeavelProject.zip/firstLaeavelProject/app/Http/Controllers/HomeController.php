<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home()
    {
        return 'Hello World From Onik';
    }
    public function bitm()
    {
        return view('bitm');
    }
    public function basis()
    {
        return "hello basis";
    }

}
